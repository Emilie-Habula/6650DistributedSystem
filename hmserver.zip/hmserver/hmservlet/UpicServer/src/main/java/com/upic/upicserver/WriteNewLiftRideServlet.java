package com.upic.upicserver;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import java.io.*;
import java.util.Arrays;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jdk.jshell.Snippet.Status;
import org.apache.commons.lang3.StringUtils;
/**
 * The servlet class extends HttpServlet to handle HTTP requests.
 * It overrides the doPost method to handle POST requests.
 * Path parameters are extracted from the request URL using req.getPathInfo().split("/").
 * Input parameters are validated, and appropriate error responses are sent if validation fails.
 * A Gson object is used for JSON serialization.
 * A LiftRide object is created with a skier id and a message ("bula").
 * The response is converted to a JSON string and sent back with the appropriate content type.
 */
public class WriteNewLiftRideServlet extends HttpServlet {
  private Gson gson = new Gson();// Initialize a Gson object for JSON serialization

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws IOException {
    // Validate input params
    String[] pathParams = req.getPathInfo().split("/");// Split the path parameters from the request URL
    System.out.println(Arrays.toString(pathParams));// Print the path parameters (for debugging)

    // Check if the number of path parameters is not equal to 8
    if(pathParams.length != 8) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "parameters mismatch");
      return;
    }

    // Check if the resort id is present or not numeric
    if(StringUtils.isEmpty(pathParams[1]) || !StringUtils.isNumeric(pathParams[1])) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "unsupported resort id");//Return a 400 Bad Request with an error message
      return;
    }

    // Check if the season id is present or equals to 2024
    if(StringUtils.isEmpty(pathParams[3]) || !pathParams[3].equals("2024")) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "unsupported resort id");//Return a 400 Bad Request with an error message
      return;
    }


    // Check if the skier id is present or not numeric
    if(StringUtils.isEmpty(pathParams[7]) ||!StringUtils.isNumeric(pathParams[7])) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "unsupported skier id");// Return a 400 Bad Request with an error message
      return;
    }
    // Check if the day id is present or equals to 1
    if(StringUtils.isEmpty(pathParams[5]) ||!pathParams[5].equals("1")) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "unsupported skier id");// Return a 400 Bad Request with an error message
      return;
    }


    // Validate resortID
    int resortID = Integer.parseInt(pathParams[1]);
    if(resortID < 1 || resortID > 10) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid resortID");// Return a 400 Bad Request with an error message
      return;
    }

    // Validate seasonID
    String seasonID = pathParams[3];
    if(!seasonID.equals("2024")) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid seasonID");// Return a 400 Bad Request with an error message
      return;
    }

    // Validate dayID
    int dayID = Integer.parseInt(pathParams[5]);
    if(dayID != 1) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid dayID");// Return a 400 Bad Request with an error message
      return;
    }

    // Validate skierID
    int skierID = Integer.parseInt(pathParams[7]);
    if(skierID < 1 || skierID > 100000) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid skierID");// Return a 400 Bad Request with an error message
      return;
    }

    // Deserialize JSON request body to a LiftRide object
    LiftRide liftRide = null;
    try {
      liftRide = gson.fromJson(req.getReader(), LiftRide.class);
      System.out.println("request body" + liftRide.getTime() + liftRide.getLiftId());
    } catch (JsonSyntaxException | JsonIOException e) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid request body");// Return a 400 Bad Request with an error message
      return;
    }

    // Check if the LiftRide object is valid
    if (!liftRide.isValid()) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid LiftRide object");// Return a 400 Bad Request with an error message
      return;
    }

    // Convert the LiftRide object to a JSON string
    String respString = this.gson.toJson(liftRide);

    // Return response
    PrintWriter out = resp.getWriter();// Get the PrintWriter for the response
    resp.setContentType("application/json");// Set the content type to JSON
    resp.setCharacterEncoding("UTF-8");// Set the character encoding
    out.print(respString);// Write the JSON response
    out.flush();// Flush the output
  }
}