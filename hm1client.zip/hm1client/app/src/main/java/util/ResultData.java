package util;

public record ResultData(double startTime,
    double endTime,
    int statusCode,
    String type){}

